Sample producer bundle used only to hash a file.
